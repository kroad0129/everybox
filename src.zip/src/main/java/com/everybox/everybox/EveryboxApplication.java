package com.everybox.everybox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EveryboxApplication {

	public static void main(String[] args) {
		SpringApplication.run(EveryboxApplication.class, args);
	}

}
