package com.everybox.everybox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EveryboxApplicationTests {

	@Test
	void contextLoads() {
	}

}
